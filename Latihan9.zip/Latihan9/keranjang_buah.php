<?php 
require_once 'class_fruit.php';

$wardah = new scincare();
$scintific = new scincare();

$scintific->set_name('cream');
$scintific->set_color('biru');
$wardah->set_name('sabun muka');
$wardah->set_color('silver');


echo 'Nama scincare wardah '.$wardah->get_name().' Warnanya '.$wardah->get_color();
echo '<br/>Nama scincare scintifik '.$scintific->get_name().' Warnanya '.$scintific->get_color();
?>