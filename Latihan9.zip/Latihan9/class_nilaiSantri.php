<?php 
class nilaisantri{
    public $nama;
    public $nilai;
    public $sekolah = 'PeTIK';

    public function get_hasil(){
        if($this->nilai > 70) return 'Lulus';
        else return 'Tidak Lulus';
    }
}
?>