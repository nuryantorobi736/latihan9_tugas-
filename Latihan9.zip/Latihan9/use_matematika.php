<?php 
require_once 'celas_matematika.php';

matematika::$counter++;
matematika::$counter++;
matematika::naikancounter();
echo'counter sekarang : '.matematika::$counter;
echo'<hr/>';


$x = matematika::tambahkan(4,5);
echo"4 + 5 = $x";
echo'<hr/>';

$x = matematika::pengurangan(35,15);
echo"35 - 15 = $x";
echo'<hr/>';

echo 'Nilai PHI : '.matematika::PHI;
$luas_lingkaran = matematika::luaslingkaran(8);
echo '<br/>Luas Lingkaran dengan Jari- Jari 8 adalah : '.$luas_lingkaran;

echo'<hr/>'


?>